﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HyruleRun
{
    class Program
    {
        private const int Row = 15;
        private const int Col = 10;
        public const char MapSymbol = '#';
         static GenerateEnemies Enemies = new GenerateEnemies();
        


        static void Main(string[] args)
        {
            
            List<Question> ListOfQuestions = Question.QuestionGenerator();
            Position PlayerPosition = new Position(1, 1);
            Console.WriteLine("Enter the name of your character: ");
            Map.Character = Console.ReadLine();
            Map.Lives = 3;

            Map.DisplayMap();


            while (true)
            {
                ConsoleKey readKey = Console.ReadKey().Key;
                if (readKey == ConsoleKey.Escape)
                {
                    return;
                }
                Console.WriteLine("Enter row");
                PlayerPosition.Row = Convert.ToInt32(Console.ReadLine());
                while (PlayerPosition.Row >= 11)
                {
                    Console.WriteLine("Please Choose an area in the map");
                    Console.WriteLine("Enter row");
                    PlayerPosition.Row = Convert.ToInt32(Console.ReadLine());
                }
                

                Console.WriteLine("Enter column");
                PlayerPosition.Column = Convert.ToInt32(Console.ReadLine());
                while (PlayerPosition.Column >= 16)
                {
                    Console.WriteLine("Please Choose an area in the map");
                    Console.WriteLine("Enter column");
                    PlayerPosition.Column = Convert.ToInt32(Console.ReadLine());
                }
                Map.map[PlayerPosition.Row -1, PlayerPosition.Column -1] = '*';

                Map.DisplayMap();
                

                // Check for and handle encounter
                bool foundEnemy = false;
                Position FoundEnemyPos = null;
                foreach (Position EnemyPos in Enemies.EnemyLocations)
                {
                    if (EnemyPos.Row == PlayerPosition.Row & EnemyPos.Column == PlayerPosition.Column)
                    {
                        Console.WriteLine("You have encountered an enemy!");
                        foundEnemy = true;
                        FoundEnemyPos = EnemyPos;
                    }  
                }

                

                if (foundEnemy)
                {
                    Random rand = new Random();

                    int n = rand.Next(0, 10);

                    string UserInput;

                    Console.WriteLine(ListOfQuestions[n].QuestionText);
                    foreach (string Ans in ListOfQuestions[n].PossibleAnswer)
                        Console.WriteLine(Ans);

                    UserInput = Console.ReadLine();

                    if (UserInput != ListOfQuestions[n].CorrectAnswer)
                    {
                        Console.WriteLine("Incorrect");
                        Map.Lives -= 1;
                        Console.ReadLine();
                        Map.DisplayMap();
                    }
                    else
                    {
                        Console.WriteLine("Correct");

                        Enemies.EnemyLocations.Remove(FoundEnemyPos);
                        Console.ReadLine();
                        Map.DisplayMap();
                    }
                }

                if (Map.Lives == 0)
                {
                    Console.WriteLine("You have lost all your lives! Press Esc to exit.");
                    if (Console.ReadKey(true).Key == ConsoleKey.Escape)
                        Console.WriteLine("See Ya Later!");
                }

                if (Enemies.EnemyLocations.Count == 0)
                {
                    Console.WriteLine("You WIN!");
                    Console.WriteLine("Do you want to play another game? Press Esc to quit");
                    if (Console.ReadKey(true).Key == ConsoleKey.Escape)
                        Console.WriteLine("See Ya Later!");
                    
                    Console.ReadLine();
                }
            }
        }


        public bool CheckEnemies()
        {
            return Enemies.EnemyLocations.Count == 0;
        }

    }
}