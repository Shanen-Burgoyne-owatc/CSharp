﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HyruleRun
{
    class Question
    {
        public string QuestionText { get; set; }

        public List<string> PossibleAnswer { get; set; }
        
        public string CorrectAnswer { get; set; }

        public static List<Question> QuestionGenerator()
        {
            List<Question> Questions = new List<Question>();

            Question tempQuestion = new Question();

            tempQuestion.QuestionText = "What is the name of the mysterious girl you meet in the Hyrule Castle sewer?";

            List<string> PosssibleAns = new List<string>();

            PosssibleAns.Add("A. Midna");
            PosssibleAns.Add("B. Zelda");
            PosssibleAns.Add("C. Ilia");
            PosssibleAns.Add("D. Telma");
            PosssibleAns.Add("E. Sheik");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "A";
            tempQuestion.CorrectAnswer = "a";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "Where must Link go to find the Master Sword?";

            PosssibleAns.Add("A. Ordon Villiage");
            PosssibleAns.Add("B. The Faron Woods");
            PosssibleAns.Add("C. The Sacred Grove");
            PosssibleAns.Add("D. The Lakebed Temple");
            PosssibleAns.Add("E. The cellar of Renado's Sanctuary");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "C";
            tempQuestion.CorrectAnswer = "c";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "Song that A Non-Living Thing teaches you in Ocarina of Time?";

            PosssibleAns.Add("A. Sun's Song");
            PosssibleAns.Add("B. Song of Healing");
            PosssibleAns.Add("C. Song of Time");
            PosssibleAns.Add("D. Song of Storms");
            PosssibleAns.Add("E. Epona's Song");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "A";
            tempQuestion.CorrectAnswer = "a";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "Why does Link grow up when he wields the Master sword in Ocarina of Time";

            PosssibleAns.Add("A. He asked for it.");
            PosssibleAns.Add("B. He couldn't carry it.");
            PosssibleAns.Add("C. He was too young to wield it.");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "C";
            tempQuestion.CorrectAnswer = "c";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "How do you obtain the Hylian Shield in Breath of the Wild?";

            PosssibleAns.Add("A. A specific Talus.");
            PosssibleAns.Add("B. A specific Stalnox.");
            PosssibleAns.Add("C. A specific Lynel.");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "B";
            tempQuestion.CorrectAnswer = "b";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "How much health does a Gold Lynel have in Breath of the Wild?";

            PosssibleAns.Add("A. 7500.");
            PosssibleAns.Add("B. 4000.");
            PosssibleAns.Add("C. 7800.");
            PosssibleAns.Add("D. 15000.");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "A";
            tempQuestion.CorrectAnswer = "a";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "How many Moldugas exist in the desert of Breath of the Wild?";

            PosssibleAns.Add("A. No specific amount");
            PosssibleAns.Add("B. 17");
            PosssibleAns.Add("C. 7");
            PosssibleAns.Add("D. There are no Moldugas");
            PosssibleAns.Add("E. 3");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "E";
            tempQuestion.CorrectAnswer = "e";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "In the original Legend of Zelda for NES, what does the Old Man say to Link before giving him a sword?";

            PosssibleAns.Add("A. There's many monsters outside. Take this sword.");
            PosssibleAns.Add("B. It's dangerous to go alone! Take this.");
            PosssibleAns.Add("C. This sword is dangerous! Be careful.");
            PosssibleAns.Add("D. Please dont take sword. It's all I have!");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "B";
            tempQuestion.CorrectAnswer = "b";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "In Twilight Princess, what animal is Link transformed into?";

            PosssibleAns.Add("A. Wolf.");
            PosssibleAns.Add("B. Ape.");
            PosssibleAns.Add("C. Rat.");
            PosssibleAns.Add("D. Hawk.");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "A";
            tempQuestion.CorrectAnswer = "a";

            Questions.Add(tempQuestion);

            tempQuestion = new Question();
            PosssibleAns = new List<string>();

            tempQuestion.QuestionText = "What's the name of Link's spirit companion in Skyward Sword?";

            PosssibleAns.Add("A. Fee.");
            PosssibleAns.Add("B. Fum.");
            PosssibleAns.Add("C. Fo.");
            PosssibleAns.Add("D. Fi.");

            tempQuestion.PossibleAnswer = PosssibleAns;

            tempQuestion.CorrectAnswer = "D";
            tempQuestion.CorrectAnswer = "d";

            Questions.Add(tempQuestion);
            return Questions;
        }
    }
}
