﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HyruleRun
{
     class GenerateEnemies
    {

        public List<Position> EnemyLocations { get; set; }


        public GenerateEnemies()
        {
            int r = 0;
            int c = 0;

            Random rand1 = new Random();
            Random rand2 = new Random();

            EnemyLocations = new List<Position>();

            while (EnemyLocations.Count < 10)
            {
                r = rand1.Next(1, 9);
                c = rand2.Next(1, 14);

                Position temp = new Position(r, c);

                bool addEnemy = true;

                foreach (Position tempos in EnemyLocations)
                {
                    if (temp.Row == tempos.Row && temp.Column == tempos.Column)
                        addEnemy = false;
                }

                if (addEnemy == true)
                    EnemyLocations.Add(temp);
            }
        }
    }
}
